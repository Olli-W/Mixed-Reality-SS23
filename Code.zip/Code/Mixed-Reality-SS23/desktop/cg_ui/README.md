# cg_ui

User Interface (2D and 3D via jMonkey) for all HAW Hamburg computer graphics projects.

## Prerequisites

* JDK 14

## Build

        gradle build

or

        ./gradlew build