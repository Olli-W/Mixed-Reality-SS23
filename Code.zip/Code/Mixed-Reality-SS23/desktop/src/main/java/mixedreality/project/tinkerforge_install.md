# Using Tinkerforge in Java/IntelliJ

* Hardware
  * Install Demon
  * Install BrickViewer (check UIDs of bricks and bricklets) 
  * see [here](https://www.tinkerforge.com/de/doc/Downloads.html)
* Java Application
  * set the actual brick and bricklet UIDs 