# cg_math

Math basics for all computer graphics applications in the HAW Hamburg computer graphics group

## Prerequisites

* JDK 14

## Build

        gradle build

or

        ./gradlew build