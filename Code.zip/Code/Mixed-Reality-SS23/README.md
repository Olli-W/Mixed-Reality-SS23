# Mixed Reality

In diesem Vorgabe-Framework bearbeiten Sie die Aufgaben für das Master-Modul *Mixed Reality*.
