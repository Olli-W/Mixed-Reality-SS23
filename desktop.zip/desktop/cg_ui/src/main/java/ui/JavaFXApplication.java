//package ui;
//
//import javafx.application.Application;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.layout.StackPane;
//import javafx.stage.Stage;
//
//public class JavaFXApplication extends Application {
//  @Override
//  public void start(Stage primaryStage) throws Exception {
//    StackPane wurzel = new StackPane();
//    wurzel.getChildren().add(new Button("Ich bin ein Knopf!"));
//    primaryStage.setScene(new Scene(wurzel, 300, 250));
//    primaryStage.show();
//  }
//
//  public static void main(String[] args) {
//    launch();
//  }
//}
